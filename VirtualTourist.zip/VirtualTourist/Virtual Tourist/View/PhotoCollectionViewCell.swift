//
//  PhotoCollectionViewCell.swift
//  Virtual Tourist
//
//  Created by Fanni Szente on 10/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import Foundation
import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var photoImageView: UIImageView!
    
}
